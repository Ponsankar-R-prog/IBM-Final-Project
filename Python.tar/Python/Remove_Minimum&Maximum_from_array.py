def minimumDeletions( nums):
    length=len(nums)-1
    if(length==1):
        return 1

    min=nums[0]
    max=nums[0]
    minIndex=0
    maxIndex=0

    for i in range(0,length+1):
        if(nums[i]<min):
            min=nums[i]
            minIndex=i

        elif(nums[i]>max):
            max=nums[i]
            maxIndex=i
    if(minIndex>maxIndex):
        (minIndex,maxIndex)=(maxIndex,minIndex)

   
    if(minIndex+1==maxIndex ):
     return maxIndex+1

    

    return ((minIndex+1)+((length+1)-maxIndex))



print(minimumDeletions( [0,-4,19,1,8,-2,-3,5] ))