def reverseString(s):
        length= len(s)
        if(length%2==0):   
            for i in range(0,(length//2)):
                first = s[i]
                s[i]=s[(length-i)-1]
                s[(length-i)-1]=first
        else:
             for i in range(0,(length//2)+1):
                first = s[i]
                s[i]=s[(length-i)-1]
                s[(length-i)-1]=first
             


print(reverseString(['a','b','c','d','e']))   